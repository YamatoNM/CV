import java.util.ArrayList;
import java.util.Comparator;

public class Tren {
    //field-uri
    protected String nume;
    public ArrayList<Vagon> vagoane;
    private ArrayList<PasageriVagon> pasageri;
    private ArrayList<TransportVagon> transport;
    private String cursa;

    //constructori
    public Tren(String nume, ArrayList<Vagon> vagoane, ArrayList<PasageriVagon> pasageri, ArrayList<TransportVagon> transport, String cursa) {
        this.nume = nume;
        this.vagoane = vagoane;
        this.pasageri = pasageri;
        this.transport = transport;
        this.cursa = cursa;
    }

    public Tren() {
        this.nume = null;
        this.vagoane = null;
        this.pasageri = null;
        this.transport = null;
        this.cursa = null;
    }

    //metode
    //greutate bagaj
    public float greutateTotalaBagaj() {
        float greutate = 0;

        for (Vagon vagon: vagoane)
            greutate += vagon.greutateBagaj;

        return greutate;
    }

    //sortare in dependenta de confort
    public ArrayList<PasageriVagon> sortConfort() {
        pasageri.sort(Comparator.comparingInt(PasageriVagon::getConfortID));
        return pasageri;
    }

    //diapazon
    public ArrayList<PasageriVagon> diapazonPasageri(int a, int b) {
        ArrayList<PasageriVagon> pasageriDiapazon = new ArrayList<>();

        for (PasageriVagon pasageri: pasageri)
            if (pasageri.getNrPasageri() >= a && pasageri.getNrPasageri() <= b)
                pasageriDiapazon.add(pasageri);

        return pasageriDiapazon;
    }
    public void addNewTren(PasageriVagon vagon){
        pasageri.add(vagon);
        vagoane.add(vagon);
    }
    public void addNewTren(TransportVagon vagon){
        transport.add(vagon);
        vagoane.add(vagon);
    }

    //toString
    @Override
    public String toString() {
        return "Tren{" +
                "nume='" + nume + '\'' +
                ", vagoane=" + vagoane +
                ", cursa='" + cursa + '\'' +
                '}';
    }
}
