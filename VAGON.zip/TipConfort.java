public enum TipConfort {
    lux,
    coupe,
    classic
}
