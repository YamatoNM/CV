import java.util.Scanner;

public class PasageriVagon extends Vagon{
    //field-uri
    private int nrPasageri;
    private TipConfort confort;
    private int confortID;

    //constructori
    public PasageriVagon(String nume, float greutateBagaj, int nrPasageri, TipConfort confort) {
        super(nume, greutateBagaj);
        this.nrPasageri = nrPasageri;
        this.confort = confort;

        if (confort.equals(TipConfort.classic))
            this.confortID = 1;

        if (confort.equals(TipConfort.coupe))
            this.confortID = 2;

        if (confort.equals(TipConfort.lux))
            this.confortID = 3;
    }

    public PasageriVagon(int nrPasageri, TipConfort confort) {
        this.nrPasageri = nrPasageri;
        if (confort.equals(TipConfort.classic))
            this.confortID = 1;

        if (confort.equals(TipConfort.coupe))
            this.confortID = 2;

        if (confort.equals(TipConfort.lux))
            this.confortID = 3;
    }

    //set and get


    public int getNrPasageri() {
        return nrPasageri;
    }

    public void setNrPasageri(int nrPasageri) {
        this.nrPasageri = nrPasageri;
    }

    public TipConfort getConfort() {
        return confort;
    }

    public void setConfort(TipConfort confort) {
        this.confort = confort;
    }

    public int getConfortID() {
        return confortID;
    }

    public void setConfortID(int confortID) {
        this.confortID = confortID;
    }

    public static  PasageriVagon addVagon() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduceti denumirea vagonului:");
        String nume = scanner.next();
        System.out.println("Introduceti greutatea bagajului:");
        float greutateBagaj = scanner.nextFloat();
        System.out.println("Introduceti numarul de pasageri:");
        int nrPasageri = scanner.nextInt();
        System.out.println("Introduceti tipul de confort(classic/coupe/lux):");
        TipConfort confort = TipConfort.valueOf(scanner.next());

        PasageriVagon v1 = new PasageriVagon(nume, greutateBagaj, nrPasageri, confort);
        return v1;
    }

    //toString


    @Override
    public String toString() {
        return "PasageriVagon{" +
                "denumire="+ nume +
                ", nrPasageri=" + nrPasageri +
                ", confort=" + confort +
                '}';
    }
}
