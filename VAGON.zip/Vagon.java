public class Vagon {
    //field-uri
    protected String nume;
    protected float greutateBagaj;

    //constructori
    public Vagon(String nume, float greutateBagaj) {
        this.nume = nume;
        this.greutateBagaj = greutateBagaj;
    }

    public Vagon() {
        this.nume = null;
        this.greutateBagaj = 0;
    }

    //set and get
    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public float getGreutateBagaj() {
        return greutateBagaj;
    }

    public void setGreutateBagaj(float greutateBagaj) {
        this.greutateBagaj = greutateBagaj;
    }

    //toString
    @Override
    public String toString() {
        return "Vagon{" +
                "nume='" + nume + '\'' +
                ", greutateBagaj=" + greutateBagaj +
                '}';
    }
}
