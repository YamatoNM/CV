import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Pasageri
        PasageriVagon pasageriVagon1 = new PasageriVagon("A10",150,50,TipConfort.classic);
        PasageriVagon pasageriVagon2 = new PasageriVagon("A20",70,20,TipConfort.coupe);
        PasageriVagon pasageriVagon3 = new PasageriVagon("A30",50,10,TipConfort.lux);

        //Transport
        TransportVagon transportVagon1 = new TransportVagon("B-10",500,"Lemn");
        TransportVagon transportVagon2 = new TransportVagon("B-20",1000,"Fier");

        //Adaugari la liste
        ArrayList<Vagon> vagoane = new ArrayList<>();
        ArrayList<PasageriVagon> pasageri = new ArrayList<>();
        ArrayList<TransportVagon> transport = new ArrayList<>();

        //lista vagoane
        vagoane.add(pasageriVagon1);
        vagoane.add(pasageriVagon2);
        vagoane.add(pasageriVagon3);
        vagoane.add(transportVagon1);
        vagoane.add(transportVagon2);

        //lista pasageri
        pasageri.add(pasageriVagon1);
        pasageri.add(pasageriVagon2);
        pasageri.add(pasageriVagon3);

        //lista transport
        transport.add(transportVagon1);
        transport.add(transportVagon2);


        //Tren
        Tren tren = new Tren("Eurostar",vagoane,pasageri,transport,"Moskva-Causeni");

        Scanner scanner = new Scanner(System.in);

        int s=9;
        while(s!=0){
            System.out.println();
            System.out.println("1. Afisarea listei Vagoanelor");
            System.out.println("2. Afisarea cantitaiide bagaj");
            System.out.println("3. Sortarea dupa nivelul de confort");
            System.out.println("4. Afisarea  trenurilor ce intra in diapazonul de pasageri introdus");
            System.out.println("5. Inserarea unui vagon transort marfa");
            System.out.println("6. Inserarea unui vagon pasager");
            System.out.println("0. Iesirea din program");
            System.out.println("Selectati optiunea pe care doriti sa o efectuati: ");
            s = scanner.nextInt();

        switch (s){
            case 1:
            for (Vagon v: vagoane) {
                System.out.println(v);}
                break;
            case 2:
                //cantitatea totala de bagaj
                System.out.println("Cantitatea totala de bagaj(kg): \n" + tren.greutateTotalaBagaj()+"\n");
                break;
            case 3:
                //sortarea dupa nivelul de confort
                System.out.println("Sortarea dupa nivelul de confort: \n" + tren.sortConfort()+ "\n");
                break;
            case 4:
                //pasageri diapazon
                System.out.println("Vagoanele dupa diapazon nr. de pasageri: \nIntroduceti diapazonul: "+"\n");
                int a = scanner.nextInt();
                int b = scanner.nextInt();

                System.out.println(tren.diapazonPasageri(a,b));
                break;
            case 5:
                TransportVagon nouVagon = TransportVagon.addVagon();
                vagoane.add(nouVagon);
                transport.add(nouVagon);
                break;

            case 6:
                PasageriVagon nouPVagon = PasageriVagon.addVagon();
                vagoane.add(nouPVagon);
                pasageri.add(nouPVagon);
                break;
            case 0 :
                break;

            default:
                    System.out.println("Valoarea introdusa nu corespunde unei metode din meniu");

            }
    }

    }
}
