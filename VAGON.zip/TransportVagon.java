import java.util.Scanner;

public class TransportVagon extends Vagon{
    //field-uri
    private String tipBagaj;

    //constructori
    public TransportVagon(String nume, float greutateBagaj, String tipBagaj) {
        super(nume, greutateBagaj);
        this.tipBagaj = tipBagaj;
    }

    public TransportVagon(String tipBagaj) {
        this.tipBagaj = tipBagaj;
    }

    public static  TransportVagon addVagon(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduceti denumirea vagonului:");
        String nume=scanner.next();
        System.out.println("Introduceti greutatea bagajului");
        float greutateBagaj= scanner.nextFloat();
        System.out.println("Introduceti tipul bagajului");
        String tipBagaj=scanner.next();
        TransportVagon vagon = new TransportVagon(nume, greutateBagaj, tipBagaj);
        return vagon;
    }
    //toString
    @Override
    public String toString() {
        return "TransportVagon{" +
                "tipBagaj='" + tipBagaj + '\'' +
                ", tip='" + nume + '\'' +
                ", greutateBagaj=" + greutateBagaj +
                '}';
    }
}
